The work was aided with help of llm, my chatgpt log is in a pdf File called "improving CA Report.pdf" 
EUAI_analysis.ipynb is my jupiter notebook that i created in vscode
European Urban Affordability Index is my document 